﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;


namespace MP3_Player
{
    public partial class Form1 : Form
    {
        WMPLib.WindowsMediaPlayer music = new WMPLib.WindowsMediaPlayer();
        TextBox textBox1 = new TextBox();
        List<TextBox> textBoxes = new List<TextBox>(5) { };
        TextBox[] boxes = new TextBox[100];
        Button[] buttons = new Button[100];
        Label[] labels = new Label[100];
        Button[] buttons2 = new Button[100];
        int[] points = new int[100];
        

        public int point = 75;
        public string name;
        public bool play = false;
        public int next;
        
        public int value = -1;
        public Form1()
        {
            InitializeComponent();
            if(music.playState == WMPLib.WMPPlayState.wmppsMediaEnded)
            {
                try
                {
                    music.controls.stop();
                    next++;
                    music.URL = boxes[next].Text;
                    music.controls.play();
                }
                catch
                {

                }
            }
            
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if(dialog.ShowDialog() == DialogResult.OK)
            {
                value++;
                
                
                point += 25;
                points[value] = point;
               //textBoxes[value] = new TextBox();
               //textBoxes[value].Location = new Point(10, 100);
               //textBoxes[value].Size = new Size(150, 50);
               //Controls.Add(textBoxes[value]);
               labels[value] = new Label();
                labels[value].Location = new Point(3, point + 3);
                labels[value].Size = new Size(20, 20);
                labels[value].Text = (value + 1).ToString();
                buttons[value] = new Button();
                buttons[value].Location = new Point(15, point);
                buttons[value].Size = new Size(20, 20);
                buttons[value].Text = "♫";
                buttons[value].Tag = value; 
                buttons[value].Click += new EventHandler(button_Click); 
                boxes[value] = new TextBox();
                boxes[value].Location = new Point(40, point);
                boxes[value].Size = new Size(150, 50);
                boxes[value].Name = ("textBox0" + value + 1).ToString();

                buttons2[value] = new Button();
                buttons2[value].Location = new Point(200, point);
                buttons2[value].Size = new Size(20, 20);
                buttons2[value].Text = "✖";
                buttons2[value].Tag = value;
                buttons2[value].Click += new EventHandler(buttons2_Click);



                Controls.Add(boxes[value]);
                Controls.Add(buttons[value]);
                Controls.Add(labels[value]);
                Controls.Add(buttons2[value]);

                // textBox1.Location = new Point(10, 100);
                //textBox1.Size = new Size(150, 50);
                //Controls.Add(textBox1);

                //textBoxes[value].Text = dialog.FileName;
                boxes[value].Text = dialog.FileName;
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(play == false)
            {
                play = true;
                music.controls.play();
                button2.Text = "∥";

            }
            else
            {
                play = false;
                music.controls.pause();
                button2.Text = "►";
            }
           // music.URL = boxes[value].Text;
            
        }
        public void button_Click(object sender, EventArgs e)
        {
            music.controls.stop();
            int index = Convert.ToInt32((sender as Button).Tag);
            next = Convert.ToInt32((sender as Button).Tag);
            music.URL = boxes[index].Text;
            music.controls.play();

        }
        public void buttons2_Click(object sender, EventArgs e)
        {
             
            int index1 = Convert.ToInt32((sender as Button).Tag);
            int labelIndex = index1;
            buttons2[index1].Dispose();
            labels[index1].Dispose();
            boxes[index1].Dispose();
            buttons[index1].Dispose();
            point -= 25;

            for (int i = index1 + 1; i <= value; i++)
            {

                labelIndex++;
                
                points[i] -= 25;
                buttons[i].Location = new Point(15, points[i]);
                buttons2[i].Location = new Point(200, points[i]);
                labels[i].Location = new Point(3, points[i]);
                labels[labelIndex].Text = labels[labelIndex - 1].Text;
                boxes[i].Location = new Point(40, points[i]);
            }

            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                music.controls.stop();
                next++;
                music.URL = boxes[next].Text;
                music.controls.play();
            }
            catch
            {

            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                music.controls.stop();
                next--;
                music.URL = boxes[next].Text;
                music.controls.play();
            }
            catch
            {

            }
            
        }
    }
}
